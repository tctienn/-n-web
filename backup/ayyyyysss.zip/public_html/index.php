<?php
    header("Location: https://objdemo.000webhostapp.com/html/");
?>
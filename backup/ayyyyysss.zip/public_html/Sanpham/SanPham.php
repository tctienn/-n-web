<h2>Danh sách sản phẩm</h2>
<div>
    <img src="http://localhost/monwebnangcao/obj_clone/nhom04/web/obj/admin/template/pages/forms/uploads/23-10-22/bg-01.jpg" alt="">
</div>
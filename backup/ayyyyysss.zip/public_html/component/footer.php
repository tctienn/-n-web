<div class="food row">
            <ul style="list-style-type: none; padding: 0;">
                <li class="col-md-2">
                    <b>VỀ CHÚNG TÔI</b>
                    <a href="#">Giới thiệu</a>
                    <a href="#">Hệ thống cửa hàng</a>
                    <a href="#">Giấy phép kinh doanh</a>
                    <a href="#">Quy chế hoạt động</a>
                    <a href="#">Chính sách đặt cọc</a>
                    <a href="#">Chính sách đổi trả thuốc</a>
                    <a href="#">Chính sách giao hàng</a>
                    <a href="#">Chính sách bảo mật</a>
                    <a href="#">Chính sách thanh toán</a>
                    <a href="#">Kiểm tra hóa đơn điện tử</a>
                    <a href="#">Tra cứu đơn hàng</a>
                </li>
                <li class="col-md-2">
                <b>VỀ CHÚNG TÔI</b>
                    <a href="#">DANH MỤC</a>
                    <a href="#">Thực phẩm chức năng</a>
                    <a href="#">Dược mỹ phẩm</a>
                    <a href="#">Chăm sóc cá nhân</a>
                    <a href="#">Thuốc</a>
                    <a href="#">Trang thiết bị y tế</a>
                    <a href="#">Bệnh</a>
                    <a href="#">Góc sức khoẻ</a>
                  
                </li>
                <li class="col-md-2">
                <b>THỰC PHẨM CHỨC NĂNG</b>
                    <a href="#">Sinh lý - Nội tiết tố</a>
                    <a href="#">Cải thiện tăng cường chức năng</a>
                    <a href="#">Thảo dược - Thực phẩm tự nhiên</a>
                    <a href="#">Vitamin</a>
                    <a href="#">Hỗ trợ điều trị</a>
                    <a href="#">Canxi và khoáng chấtc</a>
                    
                </li>
                <li class="col-md-5">
                    <div style="display: flex; justify-content: space-evenly;">
                       <div>
                            Tư vấn mua hàng (Miễn Phí) 
                            <br>
                            <h5>1800 6928 - Nhánh 1</h5>
                       </div>
                        <div>
                            Góp ý, khiếu nại (8h00-22h00) 
                            <br>
                            <h5>1800 6928 - Nhánh 2</h5>
                        </div>
                    </div>
                    <div style="background-image: url(../image/bg-footer-app.webp);">

                    </div>
                </li>
                
            </ul>
        </div>